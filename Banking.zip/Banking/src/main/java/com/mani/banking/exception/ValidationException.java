package com.mani.banking.exception;

public class ValidationException extends BankingCodedException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6578348181620309822L;
public ValidationException() {
super();
}

public ValidationException(String code){
		setCode(code);
}
}
