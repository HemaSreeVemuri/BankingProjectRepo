package com.mani.banking.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.mani.banking.dao.BankCredDao;
import com.mani.banking.dao.MemberTableDao;
import com.mani.banking.dao.RolesTableDao;
import com.mani.banking.model.BankCred;
import com.mani.banking.model.BankingUserDetails;
import com.mani.banking.model.MemTable;
import com.mani.banking.model.UserRole;

@Service
public class AuthenticationHelperService implements UserDetailsService {

	@Autowired
	private BankCredDao bankCredDao;

	@Autowired
	private MemberTableDao memberTableDao;

	@Autowired
	private RolesTableDao rolesTableDao;

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		BankingUserDetails userDetails = new BankingUserDetails();

		// BankCredential Dao related stuff
		BankCred bankCredential = bankCredDao.getbankCredByUserName(username);

		if (bankCredential == null)
			throw new UsernameNotFoundException("Not found");

		userDetails.setUsername(username);
		userDetails.setMemberID(bankCredential.getMemId());
		userDetails.setPassword(bankCredential.getPassword());

		// memberTableDao related stuff

		MemTable member = memberTableDao.getMemTableByMemId(bankCredential.getMemId());

		userDetails.setName(member.getName());
		userDetails.setAccountEnabled(transformStatusToBoolean(member.getStatus()));
		userDetails.setAccountNo(member.getAccountNumber());
		// RolesTable related stuff

		List<String> rolesString = rolesTableDao.getRolesByMemId(bankCredential.getMemId());

		userDetails.setRoles(stringToUserRole(rolesString));
		return userDetails;
	}

	private List<UserRole> stringToUserRole(List<String> rolesString) {
		List<UserRole> userRolesList = new ArrayList<UserRole>(rolesString.size());
		for (String roleString : rolesString) {
			UserRole userRole = new UserRole();
			userRole.setAuthority(roleString);
			userRolesList.add(userRole);
		}

		return userRolesList;

	}

	private boolean transformStatusToBoolean(String status) {
		if ("E".equals(status))
			return true;
		else
			return false;
	}

}
