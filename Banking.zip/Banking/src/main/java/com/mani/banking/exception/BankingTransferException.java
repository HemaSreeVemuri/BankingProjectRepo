package com.mani.banking.exception;

public class BankingTransferException extends BankingCodedException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7957260994522561587L;

	public BankingTransferException(String code) {
		setCode(code);
	}
}
