package com.mani.banking.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mani.banking.model.BalenceTable;



public class BalenceTableMap implements RowMapper<BalenceTable> {
	  public BalenceTable mapRow(ResultSet rs, int rowNum) throws SQLException {
		  
		  BalenceTable balenceTable=new BalenceTable();
		  balenceTable.setAccountNumber(rs.getInt("acno"));
		  balenceTable.setAmount(rs.getLong("amount"));
	     
	     
	      return balenceTable;
	   }

}
