package com.mani.banking.service;

import com.mani.banking.exception.ValidationException;

public class BankingValidator implements Validator {

	public Object validate(String str) throws ValidationException {
		if (str == null || str.isEmpty()) {
			throw new ValidationException("Entry Missing");
		}
		return null;
	}

}
