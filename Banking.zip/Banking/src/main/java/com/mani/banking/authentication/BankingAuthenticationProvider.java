package com.mani.banking.authentication;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.mani.banking.service.impl.AuthenticationHelperService;

@Component(value = "authenticationProvider")
public class BankingAuthenticationProvider implements AuthenticationProvider {

	@Autowired
	private AuthenticationHelperService authenticationService;

	public Authentication authenticate(Authentication authentication) throws AuthenticationException {

		String username = authentication.getName();

		UserDetails userDetails = null;
		try {
			userDetails = authenticationService.loadUserByUsername(username);
		} catch (UsernameNotFoundException ex) {
			throw new BadCredentialsException("Invalid credentials");
		}

		String password = (String) authentication.getCredentials();

		if (!userDetails.getPassword().equals(password)) {
			throw new BadCredentialsException("Invalid credentials");
		}

		return new UsernamePasswordAuthenticationToken(userDetails, password, userDetails.getAuthorities());
	}

	public boolean supports(Class<?> authentication) {
		return true;
	}

}
