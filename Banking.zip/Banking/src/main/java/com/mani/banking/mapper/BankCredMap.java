package com.mani.banking.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mani.banking.model.BankCred;

public class BankCredMap implements RowMapper<BankCred> {
	public BankCred mapRow(ResultSet rs, int rowNum) throws SQLException {
		BankCred bankCred = new BankCred();
		bankCred.setMemId(rs.getLong("MEM_ID"));
		bankCred.setUserName(rs.getString("username"));
		bankCred.setPassword(rs.getString("pass"));

		return bankCred;
	}
}
