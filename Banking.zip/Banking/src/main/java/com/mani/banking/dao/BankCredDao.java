package com.mani.banking.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mani.banking.mapper.BankCredMap;
import com.mani.banking.model.BankCred;

@Repository
public class BankCredDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public BankCred getbankCredByUserName(String userName) {
		if (userName == null || userName.isEmpty())
			return null;

		String selectQuery = "select * from bankcred where username=?";
		BankCred bankCred = null;
		try {
			bankCred = jdbcTemplate.queryForObject(selectQuery, new BankCredMap(), userName);
		} catch (EmptyResultDataAccessException exception) {
			return null;
		}

		return bankCred;

	}
	
public long getHighestMemid() {
		
		String selectQuery = "select max(MEM_ID) from bankcred";
		Long result=jdbcTemplate.queryForLong(selectQuery);
		return result;
		
	}

public void loadDetails(String username, String password, long newmwmid) {
	
	String insertQuery = "insert into bankcred values (?,?,?) ";
	jdbcTemplate.update(insertQuery,newmwmid,username,password);
	
}

}
