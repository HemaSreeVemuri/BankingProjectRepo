package com.mani.banking.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mani.banking.mapper.BalenceTableMap;
import com.mani.banking.model.BalenceTable;

@Repository
public class BalenceTableDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public long getBalence(long acno) {
		String selectQuery = "select * from balencetable where acno=?";
		BalenceTable balenceTable = null;

		balenceTable = jdbcTemplate.queryForObject(selectQuery, new BalenceTableMap(), acno);

		return balenceTable.getAmount();

	}

	public long getHighestAcno() {

		String selectQuery = "select max(acno) from balencetable";
		Long result = jdbcTemplate.queryForLong(selectQuery);
		return result;
	}

	public void loadRecord(long newAcNo, long l) {
		String insertQuery = "insert into balencetable values (?,?) ";
		jdbcTemplate.update(insertQuery, newAcNo, l);

	}

}
