package com.mani.banking.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mani.banking.service.impl.RegisterDetailsService;

@Controller
public class RegisterController {

	@Autowired
	private RegisterDetailsService registerDetailsService;

	@RequestMapping(value = "registerdetails", method = RequestMethod.POST)
	public ModelAndView loginHandler(HttpServletRequest request, Model model) {
		String fullName = (String) request.getParameter("fullName");
		String ssn = (String) request.getParameter("ssn");
		String username = (String) request.getParameter("username");
		String password = (String) request.getParameter("password");
		String place = (String) request.getParameter("place");
		String status = "e";
		String role = "ROLE_USER";

		registerDetailsService.registerDetails(fullName, ssn, username, password, place, status, role);
		ModelAndView modelAndView = new ModelAndView("login");

		modelAndView.addObject("textmsg", "Registered successfully please login");

		return modelAndView;
	}
}
