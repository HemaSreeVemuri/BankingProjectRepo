package com.mani.banking.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mani.banking.mapper.RolesTableMapper;
import com.mani.banking.model.RolesTable;

@Repository
public class RolesTableDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<String> getRolesByMemId(Long memid) {

		String query = "select * from roles where mem_id=?";
		List<RolesTable> list = jdbcTemplate.query(query, new RolesTableMapper(), memid);
		List<String> reslist = new ArrayList<String>();
		for (RolesTable rolesTable : list) {
			reslist.add(rolesTable.getRole());
		}

		return reslist;
	}

	public void loadRole(long newmwmid, String role) {
		String insertQuery = "insert into roles values (?,?) ";
		jdbcTemplate.update(insertQuery,newmwmid,role);		
	}

}
