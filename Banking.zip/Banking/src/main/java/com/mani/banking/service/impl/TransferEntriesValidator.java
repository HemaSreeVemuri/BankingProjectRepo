package com.mani.banking.service.impl;

import org.springframework.stereotype.Service;

import com.mani.banking.exception.ValidationException;
import com.mani.banking.service.BankingValidator;

@Service
public class TransferEntriesValidator extends BankingValidator {

	public Long validate(String str) throws ValidationException {
		super.validate(str);
		Long number = 0l;
		try {
			number = Long.parseLong(str);
		} catch (NumberFormatException ex) {
			throw new ValidationException("Invalid entry");
		}

		if (number <= 0l) {
			throw new ValidationException("Invalid Negative entry");
		}

		return number;

	}

}
