package com.mani.banking.model;

import org.springframework.security.core.GrantedAuthority;

public class UserRole implements GrantedAuthority {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4048230855704934454L;
	private String authority;

	public String getAuthority() {
		return authority;
	}

	public void setAuthority(String authority) {
		this.authority = authority;
	}

}
