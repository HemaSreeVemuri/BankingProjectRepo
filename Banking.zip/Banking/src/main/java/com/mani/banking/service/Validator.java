package com.mani.banking.service;

import com.mani.banking.exception.ValidationException;

public interface Validator {

	public Object validate(String str) throws ValidationException;

}
