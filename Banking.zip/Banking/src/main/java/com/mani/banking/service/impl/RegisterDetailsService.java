package com.mani.banking.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mani.banking.dao.BalenceTableDao;
import com.mani.banking.dao.BankCredDao;
import com.mani.banking.dao.MemberTableDao;
import com.mani.banking.dao.RolesTableDao;

import oracle.net.aso.b;

@Service
public class RegisterDetailsService {

	@Autowired
	private BankCredDao bankCredDao;
	
	@Autowired
	private BalenceTableDao balenceTableDao;
	
	@Autowired
	private MemberTableDao memberTableDao;
	
	@Autowired
	private RolesTableDao rolesTableDao;
	
	public boolean registerDetails(String fullName, String ssn, String username, String password, String place,String status, String role) {
		
	long newmwmid=bankCredDao.getHighestMemid();
	long newAcNo=balenceTableDao.getHighestAcno();
	newAcNo++;
	newmwmid++;
	
	
	bankCredDao.loadDetails(username,password,newmwmid);
	memberTableDao.loadDetails(newAcNo,newmwmid,fullName,place,ssn,status);
	balenceTableDao.loadRecord(newAcNo,10000l);
	
	rolesTableDao.loadRole(newmwmid,role);
	
	return true;
	
	}

}
