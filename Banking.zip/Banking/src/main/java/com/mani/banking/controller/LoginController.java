package com.mani.banking.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mani.banking.model.BankingUserDetails;
import com.mani.banking.model.GlobalUserDetails;
import com.mani.banking.service.impl.BalenceService;

@Controller
public class LoginController {

	@Autowired
	private BalenceService balenceService;

	@Autowired
	private GlobalUserDetails userDetails;

	@RequestMapping(value = "login", method = RequestMethod.GET)
	public ModelAndView loginHandler(HttpServletRequest request, Model model) {

		BankingUserDetails securityUserDetails = (BankingUserDetails) SecurityContextHolder.getContext()
				.getAuthentication().getPrincipal();

		securityUserDetails.saveTo(this.userDetails);

		ModelAndView modelAndView = new ModelAndView("HomePage");
		setBalance();
		setBaseMap(modelAndView);
		String error = request.getParameter("error");
		if (error != null) {
			modelAndView.addObject("error", error);
		}
		return modelAndView;

	}

	private void setBalance() {
		userDetails.setBalance(balenceService.getAmount(userDetails.getAccountNo()));
	}

	private void setBaseMap(ModelAndView modelAndView) {
		modelAndView.addObject("name", userDetails.getName());
		modelAndView.addObject("memid", userDetails.getMemberID());
		modelAndView.addObject("acno", userDetails.getAccountNo());
		modelAndView.addObject("amount", balenceService.getAmount(userDetails.getAccountNo()));
	}

	@RequestMapping(value = "registeruser", method = RequestMethod.POST)
	public ModelAndView registerHandler(HttpServletRequest request) {
		ModelAndView modelAndView = new ModelAndView("RegisterPage");
		return modelAndView;
	}

}
