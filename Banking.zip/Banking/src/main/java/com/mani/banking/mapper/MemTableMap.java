package com.mani.banking.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mani.banking.model.MemTable;

public class MemTableMap implements RowMapper<MemTable> {

	public MemTable mapRow(ResultSet rs, int rowNum) throws SQLException {
		MemTable memTable = new MemTable();
		memTable.setAccountNumber(rs.getLong("acno"));
		memTable.setMemberId(rs.getLong("mem_id"));
		memTable.setName(rs.getString("name"));
		memTable.setPlace(rs.getString("place"));
		memTable.setSsn(rs.getString("ssn"));
		memTable.setStatus(rs.getString("status"));
		return memTable;
	}
}
