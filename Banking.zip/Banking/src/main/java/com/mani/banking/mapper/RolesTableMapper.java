package com.mani.banking.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mani.banking.model.RolesTable;

public class RolesTableMapper implements RowMapper<RolesTable> {
	public RolesTable mapRow(ResultSet rs, int rowNum) throws SQLException {

		RolesTable rolesTable = new RolesTable();
		rolesTable.setMemid(rs.getInt("mem_id"));
		rolesTable.setRole(rs.getString("role"));

		return rolesTable;
	}

}
