package com.mani.banking.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mani.banking.exception.BankingTransferException;
import com.mani.banking.exception.ValidationException;
import com.mani.banking.model.GlobalUserDetails;

@Service
public class TransferService {

	@Autowired
	private GlobalUserDetails userDetails;

	// @Autowired
	// private TransactionTemplate transactionTemplate;

	@Autowired
	private BalenceService balanceService;

	@Autowired
	private TransferTransaction transferTransaction;

	@Autowired
	private TransferEntriesValidator validator;

	public void transfer(String transferAmountString, String destinationAccountString) throws BankingTransferException {

		Long transferAmount;
		Long transferAccount;

		try {
			transferAmount = validator.validate(transferAmountString);
		} catch (ValidationException ex) {
			throw new BankingTransferException("Invalid transferAmount::" + ex.getCode());
		}
		try {
			transferAccount = validator.validate(destinationAccountString);
		} catch (ValidationException ex) {
			throw new BankingTransferException("Invalid destinationAccount::" + ex.getCode());
		}
		if (userDetails.getBalance() < transferAmount) {
			throw new BankingTransferException("IN SUFFICIENT FUNDS");
		}

		if (!balanceService.isValidAccount(transferAccount)) {
			throw new BankingTransferException("ACCOUNT " + transferAccount + " INACTIVE");
		}

		transferTransaction.setTransferAccount(transferAccount);
		transferTransaction.setTransferAmount(transferAmount);
		// transactionTemplate.execute(transferTransaction);

		transferInTrasaction();

	}

	@Transactional(value = "")
	private void transferInTrasaction() {
		transferTransaction.doInTransaction(null);
	}
}
