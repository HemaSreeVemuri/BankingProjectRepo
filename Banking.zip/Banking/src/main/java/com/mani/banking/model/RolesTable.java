package com.mani.banking.model;

public class RolesTable {
int memid;
String role;
public int getMemid() {
	return memid;
}
public void setMemid(int memid) {
	this.memid = memid;
}
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}

}
