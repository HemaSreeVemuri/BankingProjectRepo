package com.mani.banking.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.mani.banking.dao.BalenceTableDao;

@Service
public class BalenceService {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private BalenceTableDao balenceTableDao;

	public void updateAmount(long acno, long updatableAmount) {
		String selectQuery = "update balencetable set amount=? where acno=?";

		jdbcTemplate.update(selectQuery, updatableAmount, acno);

	}

	public Long getAmount(long acno) {

		String selectQuery = "select amount from balencetable where acno=?";
		Long result = jdbcTemplate.queryForLong(selectQuery, acno);
		return result;
	}

	public boolean isValidAccount(long transferAccount) {
		try {
			String selectQuery = "select amount from balencetable where acno=?";
			Long result = jdbcTemplate.queryForLong(selectQuery, transferAccount);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

}
