package com.mani.banking.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mani.banking.mapper.MemTableMap;
import com.mani.banking.model.MemTable;

@Repository
public class MemberTableDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public MemTable getMemTableByMemId(Long id) {
		String selectQuery = "select * from memtable where mem_id=?";
		MemTable memTable = null;

		memTable = jdbcTemplate.queryForObject(selectQuery, new MemTableMap(), id);

		return memTable;
	}
	public long loadDetailsIntoDetails()
	{
		
		return 000000;
		
	}
	
	public void loadDetails(long newAcNo, long newmwmid, String fullName, String place, String ssn, String role) {
		String insertQuery = "insert into memtable values (?,?,?,?,?,?) ";
		jdbcTemplate.update(insertQuery,newAcNo,newmwmid,fullName,place,ssn,role);	
		
	}

}


