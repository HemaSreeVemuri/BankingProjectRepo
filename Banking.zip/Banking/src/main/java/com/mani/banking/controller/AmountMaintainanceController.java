package com.mani.banking.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mani.banking.exception.BankingTransferException;
import com.mani.banking.model.GlobalUserDetails;
import com.mani.banking.service.impl.BalenceService;
import com.mani.banking.service.impl.TransferService;

@Controller
public class AmountMaintainanceController {

	@Autowired
	private BalenceService balenceService;

	@Autowired
	private TransferService transferService;

	@Autowired
	private GlobalUserDetails userDetails;

	@RequestMapping(value = "withdrawOperation", method = RequestMethod.POST)
	public ModelAndView withdrawOperation(HttpServletRequest request) {

		String str = request.getParameter("withdrawAmount");

		ModelAndView modelAndView = new ModelAndView("redirect:/login");

		if (str == null || str.isEmpty()) {
			modelAndView.addObject("error", "please enter amount before requesting");
			return modelAndView;
		}

		long amountwith = Long.parseLong(str);

		if (userDetails.getBalance() < amountwith) {
			modelAndView.addObject("error", "you are trying to overdraw");
			return modelAndView;
		}
		balenceService.updateAmount(userDetails.getAccountNo(), userDetails.getBalance() - amountwith);
		return modelAndView;
	}

	@RequestMapping(value = "depositOperation", method = RequestMethod.POST)
	public ModelAndView depositOperation(HttpServletRequest request) {

		String str = request.getParameter("depositAmount");

		ModelAndView modelAndView = new ModelAndView("redirect:/login");
		if (str == null || str.isEmpty()) {
			modelAndView.addObject("error", "please enter amount");
			return modelAndView;
		}

		long amountDep = Long.parseLong(str);

		balenceService.updateAmount(userDetails.getAccountNo(), userDetails.getBalance() + amountDep);
		return modelAndView;
	}

	@RequestMapping(value = "transferOperation", method = RequestMethod.POST)
	public ModelAndView transferOperation(HttpServletRequest request) {

		String transferAmountSString = request.getParameter("transferAmount");
		String transferAcountString = request.getParameter("acno");

		ModelAndView modelAndView = new ModelAndView("redirect:/login");

		try {
			transferService.transfer(transferAmountSString, transferAcountString);
		} catch (BankingTransferException ex) {
			modelAndView.addObject("error", ex.getCode());
		}
		return modelAndView;

	}

}