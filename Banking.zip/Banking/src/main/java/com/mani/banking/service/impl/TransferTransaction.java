package com.mani.banking.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;

import com.mani.banking.model.GlobalUserDetails;

@Component
@Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class TransferTransaction implements TransactionCallback<Object> {

	@Autowired
	private BalenceService balanceService;

	@Autowired
	private GlobalUserDetails userDetails;

	private Long transferAmount;
	private Long transferAccount;

	public TransferTransaction() {
	}

	public TransferTransaction(Long transferAmount, Long transferAccount) {
		this.transferAmount = transferAmount;
		this.transferAccount = transferAccount;
	}

	private void transfer() throws Exception {

		balanceService.updateAmount(userDetails.getAccountNo(), userDetails.getBalance() - transferAmount);
		userDetails.setBalance(userDetails.getBalance() - transferAmount);
		balanceService.updateAmount(transferAccount, balanceService.getAmount(transferAccount) + transferAmount);

	}

	public Object doInTransaction(TransactionStatus arg0) {
		try {
			transfer();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return null;
	}

	public void setTransferAmount(Long transferAmount) {
		this.transferAmount = transferAmount;
	}

	public void setTransferAccount(Long transferAccount) {
		this.transferAccount = transferAccount;
	}

}
